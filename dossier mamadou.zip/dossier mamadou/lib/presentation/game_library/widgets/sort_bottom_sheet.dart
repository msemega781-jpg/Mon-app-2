import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SortBottomSheet extends StatelessWidget {
  final String currentSort;
  final Function(String) onSortChanged;

  const SortBottomSheet({
    super.key,
    required this.currentSort,
    required this.onSortChanged,
  });

  @override
  Widget build(BuildContext context) {
    final sortOptions = [
      {'key': 'recent', 'title': 'Récemment joués', 'icon': 'access_time'},
      {
        'key': 'alphabetical',
        'title': 'Ordre alphabétique',
        'icon': 'sort_by_alpha'
      },
      {'key': 'install_date', 'title': 'Date d\'installation', 'icon': 'event'},
      {'key': 'file_size', 'title': 'Taille du fichier', 'icon': 'storage'},
      {'key': 'rating', 'title': 'Note', 'icon': 'star'},
    ];

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.only(top: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.borderColor,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(6.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Trier par',
                  style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4.h),
                ...sortOptions.map((option) => _buildSortOption(
                      context,
                      key: option['key'] as String,
                      title: option['title'] as String,
                      icon: option['icon'] as String,
                      isSelected: currentSort == option['key'],
                    )),
                SizedBox(height: 2.h),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSortOption(
    BuildContext context, {
    required String key,
    required String title,
    required String icon,
    required bool isSelected,
  }) {
    return GestureDetector(
      onTap: () {
        onSortChanged(key);
        Navigator.pop(context);
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.accentColor.withValues(alpha: 0.1)
              : AppTheme.cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppTheme.accentColor.withValues(alpha: 0.5)
                : AppTheme.borderColor.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: isSelected ? AppTheme.accentColor : AppTheme.textSecondary,
              size: 20,
            ),
            SizedBox(width: 4.w),
            Expanded(
              child: Text(
                title,
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color:
                      isSelected ? AppTheme.accentColor : AppTheme.textPrimary,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                ),
              ),
            ),
            if (isSelected)
              CustomIconWidget(
                iconName: 'check',
                color: AppTheme.accentColor,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }
}
