import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SystemHealthHeaderWidget extends StatefulWidget {
  const SystemHealthHeaderWidget({super.key});

  @override
  State<SystemHealthHeaderWidget> createState() =>
      _SystemHealthHeaderWidgetState();
}

class _SystemHealthHeaderWidgetState extends State<SystemHealthHeaderWidget> {
  final List<Map<String, dynamic>> healthIndicators = [
    {
      "label": "CPU",
      "status": "optimal",
      "value": "52%",
      "color": AppTheme.successColor,
      "icon": "memory",
    },
    {
      "label": "GPU",
      "status": "attention",
      "value": "78%",
      "color": AppTheme.warningColor,
      "icon": "videogame_asset",
    },
    {
      "label": "RAM",
      "status": "critique",
      "value": "87%",
      "color": AppTheme.errorColor,
      "icon": "storage",
    },
    {
      "label": "Thermique",
      "status": "optimal",
      "value": "42°C",
      "color": AppTheme.successColor,
      "icon": "thermostat",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.cardColor,
            AppTheme.surfaceColor,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.borderColor.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.accentColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: CustomIconWidget(
                  iconName: 'dashboard',
                  color: AppTheme.accentColor,
                  size: 28,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Tableau de Bord Performance',
                      style:
                          AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      'Surveillance en temps réel',
                      style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              _buildOverallHealthBadge(),
            ],
          ),
          SizedBox(height: 3.h),
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.primaryDark.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.borderColor.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info_outline',
                      color: AppTheme.accentColor,
                      size: 18,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'État Système Global',
                      style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  children: healthIndicators.map((indicator) {
                    return Expanded(
                      child: Container(
                        margin: EdgeInsets.only(
                          right: healthIndicators.indexOf(indicator) <
                                  healthIndicators.length - 1
                              ? 2.w
                              : 0,
                        ),
                        child: _buildHealthIndicator(
                          indicator['label'] as String,
                          indicator['value'] as String,
                          indicator['status'] as String,
                          indicator['color'] as Color,
                          indicator['icon'] as String,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildQuickStat(
                  'Session Active',
                  '2h 34m',
                  AppTheme.accentColor,
                  'access_time',
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildQuickStat(
                  'FPS Moyen',
                  '58.2',
                  AppTheme.successColor,
                  'speed',
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildQuickStat(
                  'Batterie',
                  '67%',
                  AppTheme.warningColor,
                  'battery_3_bar',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOverallHealthBadge() {
    final int healthyCount = healthIndicators
        .where((indicator) => indicator['status'] == 'optimal')
        .length;
    final int totalCount = healthIndicators.length;
    final double healthPercentage = (healthyCount / totalCount) * 100;

    Color badgeColor;
    String badgeText;
    String badgeIcon;

    if (healthPercentage >= 75) {
      badgeColor = AppTheme.successColor;
      badgeText = 'EXCELLENT';
      badgeIcon = 'check_circle';
    } else if (healthPercentage >= 50) {
      badgeColor = AppTheme.warningColor;
      badgeText = 'ATTENTION';
      badgeIcon = 'warning';
    } else {
      badgeColor = AppTheme.errorColor;
      badgeText = 'CRITIQUE';
      badgeIcon = 'error';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: badgeColor.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: badgeColor.withValues(alpha: 0.5),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: badgeIcon,
            color: badgeColor,
            size: 16,
          ),
          SizedBox(width: 1.w),
          Text(
            badgeText,
            style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
              color: badgeColor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHealthIndicator(
      String label, String value, String status, Color color, String iconName) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: CustomIconWidget(
            iconName: iconName,
            color: color,
            size: 20,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          label,
          style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
            color: AppTheme.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: AppTheme.dataTextTheme().bodyMedium?.copyWith(
                color: color,
                fontWeight: FontWeight.w600,
              ),
          textAlign: TextAlign.center,
        ),
        SizedBox(height: 0.5.h),
        Container(
          width: double.infinity,
          height: 3,
          decoration: BoxDecoration(
            color: AppTheme.borderColor.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(2),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: _getStatusProgress(status),
            child: Container(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickStat(
      String label, String value, Color color, String iconName) {
    return Container(
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: iconName,
            color: color,
            size: 18,
          ),
          SizedBox(height: 0.5.h),
          Text(
            value,
            style: AppTheme.dataTextTheme().bodyMedium?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w600,
                ),
            textAlign: TextAlign.center,
          ),
          Text(
            label,
            style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
              color: AppTheme.textSecondary,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  double _getStatusProgress(String status) {
    switch (status.toLowerCase()) {
      case 'optimal':
        return 1.0;
      case 'attention':
        return 0.6;
      case 'critique':
        return 0.3;
      default:
        return 0.5;
    }
  }
}
