import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SensitivitySettingsWidget extends StatefulWidget {
  final Map<String, double> sensitivityValues;
  final Function(Map<String, double>) onSensitivityChanged;

  const SensitivitySettingsWidget({
    Key? key,
    required this.sensitivityValues,
    required this.onSensitivityChanged,
  }) : super(key: key);

  @override
  State<SensitivitySettingsWidget> createState() =>
      _SensitivitySettingsWidgetState();
}

class _SensitivitySettingsWidgetState extends State<SensitivitySettingsWidget> {
  late Map<String, double> _currentValues;
  bool _isTestingMode = false;

  @override
  void initState() {
    super.initState();
    _currentValues = Map<String, double>.from(widget.sensitivityValues);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.darkTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'tune',
                color: AppTheme.accentColor,
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text(
                'Réglages de Sensibilité',
                style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Spacer(),
              Switch(
                value: _isTestingMode,
                onChanged: (value) {
                  setState(() {
                    _isTestingMode = value;
                  });
                },
              ),
              Text(
                'Test',
                style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildSensitivitySlider(
            'Stick Gauche - Zone Morte',
            'left_deadzone',
            0.0,
            0.3,
            'Réduit les mouvements involontaires',
            CustomIconWidget(
              iconName: 'gamepad',
              color: AppTheme.accentColor,
              size: 5.w,
            ),
          ),
          SizedBox(height: 2.h),
          _buildSensitivitySlider(
            'Stick Droit - Zone Morte',
            'right_deadzone',
            0.0,
            0.3,
            'Contrôle de la caméra/visée',
            CustomIconWidget(
              iconName: 'camera',
              color: AppTheme.accentColor,
              size: 5.w,
            ),
          ),
          SizedBox(height: 2.h),
          _buildSensitivitySlider(
            'Sensibilité Gâchette Gauche',
            'left_trigger',
            0.1,
            1.0,
            'Réactivité de la gâchette LT',
            CustomIconWidget(
              iconName: 'speed',
              color: AppTheme.warningColor,
              size: 5.w,
            ),
          ),
          SizedBox(height: 2.h),
          _buildSensitivitySlider(
            'Sensibilité Gâchette Droite',
            'right_trigger',
            0.1,
            1.0,
            'Réactivité de la gâchette RT',
            CustomIconWidget(
              iconName: 'speed',
              color: AppTheme.warningColor,
              size: 5.w,
            ),
          ),
          SizedBox(height: 2.h),
          _buildSensitivitySlider(
            'Intensité Vibration',
            'vibration',
            0.0,
            1.0,
            'Force du retour haptique',
            CustomIconWidget(
              iconName: 'vibration',
              color: AppTheme.successColor,
              size: 5.w,
            ),
          ),
          SizedBox(height: 2.h),
          _buildSensitivitySlider(
            'Sensibilité Gyroscope',
            'gyroscope',
            0.1,
            2.0,
            'Contrôle par mouvement du téléphone',
            CustomIconWidget(
              iconName: 'screen_rotation',
              color: AppTheme.accentColor,
              size: 5.w,
            ),
          ),
          if (_isTestingMode) ...[
            SizedBox(height: 3.h),
            _buildTestingArea(),
          ],
          SizedBox(height: 3.h),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _resetToDefaults,
                  child: Text('Réinitialiser'),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: ElevatedButton(
                  onPressed: _saveSettings,
                  child: Text('Sauvegarder'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSensitivitySlider(
    String title,
    String key,
    double min,
    double max,
    String description,
    Widget icon,
  ) {
    final value = _currentValues[key] ?? (min + max) / 2;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            icon,
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    description,
                    style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
              decoration: BoxDecoration(
                color: AppTheme.primaryDark,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppTheme.borderColor),
              ),
              child: Text(
                '${(value * 100).toInt()}%',
                style: AppTheme.dataTextTheme().labelMedium?.copyWith(
                      color: AppTheme.accentColor,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ),
          ],
        ),
        SizedBox(height: 1.h),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: AppTheme.accentColor,
            inactiveTrackColor: AppTheme.borderColor,
            thumbColor: AppTheme.accentColor,
            overlayColor: AppTheme.accentColor.withValues(alpha: 0.2),
            trackHeight: 4,
            thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
          ),
          child: Slider(
            value: value,
            min: min,
            max: max,
            divisions: 20,
            onChanged: (newValue) {
              setState(() {
                _currentValues[key] = newValue;
              });
              if (_isTestingMode) {
                _testSensitivity(key, newValue);
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildTestingArea() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.primaryDark,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.accentColor.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'science',
                color: AppTheme.accentColor,
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'Mode Test Actif',
                style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                  color: AppTheme.accentColor,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Container(
            height: 15.h,
            width: double.infinity,
            decoration: BoxDecoration(
              color: AppTheme.secondaryDark,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.borderColor),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'gamepad',
                    color: AppTheme.textSecondary,
                    size: 8.w,
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    'Utilisez votre contrôleur pour tester',
                    style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  Text(
                    'les nouveaux réglages en temps réel',
                    style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _testSensitivity(String key, double value) {
    // Simulate haptic feedback for testing
    // In a real implementation, this would communicate with the controller
    print('Testing $key with value: $value');
  }

  void _resetToDefaults() {
    setState(() {
      _currentValues = {
        'left_deadzone': 0.1,
        'right_deadzone': 0.1,
        'left_trigger': 0.5,
        'right_trigger': 0.5,
        'vibration': 0.7,
        'gyroscope': 1.0,
      };
    });
    widget.onSensitivityChanged(_currentValues);
  }

  void _saveSettings() {
    widget.onSensitivityChanged(_currentValues);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Réglages de sensibilité sauvegardés'),
        backgroundColor: AppTheme.successColor,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
