import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/control_element_widget.dart';
import './widgets/control_palette_widget.dart';
import './widgets/control_properties_widget.dart';
import './widgets/preset_templates_widget.dart';
import './widgets/preview_mode_widget.dart';

class TouchControlsEditor extends StatefulWidget {
  const TouchControlsEditor({Key? key}) : super(key: key);

  @override
  State<TouchControlsEditor> createState() => _TouchControlsEditorState();
}

class _TouchControlsEditorState extends State<TouchControlsEditor> {
  List<Map<String, dynamic>> _controls = [];
  String? _selectedControlId;
  bool _isPreviewMode = false;
  bool _hasUnsavedChanges = false;
  bool _isAutoSaving = false;

  // Mock game background data
  final List<Map<String, dynamic>> _gameBackgrounds = [
    {
      "id": "cyberpunk_2077",
      "name": "Cyberpunk 2077",
      "image":
          "https://images.unsplash.com/photo-1518709268805-4e9042af2176?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "genre": "RPG",
    },
    {
      "id": "valorant",
      "name": "Valorant",
      "image":
          "https://images.unsplash.com/photo-1542751371-adc38448a05e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "genre": "FPS",
    },
    {
      "id": "forza_horizon",
      "name": "Forza Horizon 5",
      "image":
          "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "genre": "Racing",
    },
  ];

  String _currentGameId = "cyberpunk_2077";

  @override
  void initState() {
    super.initState();
    _loadDefaultControls();
  }

  void _loadDefaultControls() {
    _controls = [
      {
        'id': 'default_joystick',
        'type': 'joystick',
        'label': 'Mouvement',
        'x': 8.w,
        'y': 65.h,
        'size': 1.0,
        'opacity': 0.8,
        'sensitivity': 1.0,
      },
      {
        'id': 'default_action_a',
        'type': 'action_button',
        'label': 'A',
        'x': 80.w,
        'y': 60.h,
        'size': 1.0,
        'opacity': 0.8,
        'sensitivity': 1.0,
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    if (_isPreviewMode) {
      return PreviewModeWidget(
        controls: _controls,
        onExit: () => setState(() => _isPreviewMode = false),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundPrimary,
      body: Stack(
        children: [
          // Game background
          _buildGameBackground(),

          // Semi-transparent overlay
          Container(
            width: double.infinity,
            height: double.infinity,
            color: AppTheme.primaryDark.withValues(alpha: 0.3),
          ),

          // Top toolbar
          _buildTopToolbar(),

          // Control elements
          ..._controls.map((control) => ControlElementWidget(
                controlData: control,
                isSelected: _selectedControlId == control['id'],
                onTap: () => _selectControl(control['id'] as String),
                onDrag: (delta) => _moveControl(control['id'] as String, delta),
                onLongPress: () => _showControlProperties(control),
              )),

          // Bottom control palette
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: ControlPaletteWidget(
              onControlAdd: _addControl,
            ),
          ),

          // Auto-save indicator
          if (_isAutoSaving) _buildAutoSaveIndicator(),
        ],
      ),
    );
  }

  Widget _buildGameBackground() {
    final currentGame = _gameBackgrounds.firstWhere(
      (game) => game['id'] == _currentGameId,
      orElse: () => _gameBackgrounds.first,
    );

    return Container(
      width: double.infinity,
      height: double.infinity,
      child: CustomImageWidget(
        imageUrl: currentGame['image'] as String,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.cover,
      ),
    );
  }

  Widget _buildTopToolbar() {
    return Positioned(
      top: 6.h,
      left: 0,
      right: 0,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Cancel button
            GestureDetector(
              onTap: _showExitConfirmation,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceColor.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.borderColor),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: 'close',
                      color: AppTheme.textPrimary,
                      size: 4.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Annuler',
                      style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Center actions
            Row(
              children: [
                // Game selector
                GestureDetector(
                  onTap: _showGameSelector,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceColor.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'videogame_asset',
                          color: AppTheme.accentColor,
                          size: 4.w,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          _gameBackgrounds.firstWhere(
                                  (g) => g['id'] == _currentGameId)['name']
                              as String,
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(width: 1.w),
                        CustomIconWidget(
                          iconName: 'keyboard_arrow_down',
                          color: AppTheme.textSecondary,
                          size: 3.w,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 3.w),

                // Preset templates button
                GestureDetector(
                  onTap: _showPresetTemplates,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceColor.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'dashboard',
                          color: AppTheme.warningColor,
                          size: 4.w,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Modèles',
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Right actions
            Row(
              children: [
                // Preview button
                GestureDetector(
                  onTap: () => setState(() => _isPreviewMode = true),
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppTheme.accentColor.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.accentColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'play_arrow',
                          color: AppTheme.accentColor,
                          size: 4.w,
                        ),
                        SizedBox(width: 1.w),
                        Text(
                          'Test',
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.accentColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 2.w),

                // Reset button
                GestureDetector(
                  onTap: _showResetConfirmation,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceColor.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'refresh',
                          color: AppTheme.warningColor,
                          size: 4.w,
                        ),
                        SizedBox(width: 1.w),
                        Text(
                          'Reset',
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 2.w),

                // Save button
                GestureDetector(
                  onTap: _saveControls,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: AppTheme.successColor,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'save',
                          color: AppTheme.primaryDark,
                          size: 4.w,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Sauvegarder',
                          style:
                              AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                            color: AppTheme.primaryDark,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAutoSaveIndicator() {
    return Positioned(
      top: 15.h,
      right: 4.w,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.successColor.withValues(alpha: 0.9),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 3.w,
              height: 3.w,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryDark),
              ),
            ),
            SizedBox(width: 2.w),
            Text(
              'Sauvegarde automatique...',
              style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.primaryDark,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _selectControl(String controlId) {
    setState(() {
      _selectedControlId = _selectedControlId == controlId ? null : controlId;
    });
    HapticFeedback.selectionClick();
  }

  void _moveControl(String controlId, Offset delta) {
    final controlIndex = _controls.indexWhere((c) => c['id'] == controlId);
    if (controlIndex != -1) {
      setState(() {
        _controls[controlIndex]['x'] =
            (_controls[controlIndex]['x'] as double) + delta.dx;
        _controls[controlIndex]['y'] =
            (_controls[controlIndex]['y'] as double) + delta.dy;
        _hasUnsavedChanges = true;
      });
      _triggerAutoSave();
    }
  }

  void _addControl(Map<String, dynamic> controlData) {
    setState(() {
      _controls.add(controlData);
      _selectedControlId = controlData['id'] as String;
      _hasUnsavedChanges = true;
    });
    HapticFeedback.lightImpact();
    _triggerAutoSave();
  }

  void _showControlProperties(Map<String, dynamic> control) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ControlPropertiesWidget(
        controlData: control,
        onUpdate: (updatedControl) {
          final index =
              _controls.indexWhere((c) => c['id'] == updatedControl['id']);
          if (index != -1) {
            setState(() {
              _controls[index] = updatedControl;
              _hasUnsavedChanges = true;
            });
            _triggerAutoSave();
          }
        },
        onDelete: () {
          setState(() {
            _controls.removeWhere((c) => c['id'] == control['id']);
            _selectedControlId = null;
            _hasUnsavedChanges = true;
          });
          Navigator.pop(context);
          _triggerAutoSave();
        },
      ),
    );
  }

  void _showPresetTemplates() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => PresetTemplatesWidget(
        onPresetLoad: (presetControls) {
          setState(() {
            _controls = presetControls;
            _selectedControlId = null;
            _hasUnsavedChanges = true;
          });
          Navigator.pop(context);
          _triggerAutoSave();
        },
      ),
    );
  }

  void _showGameSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surfaceColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sélectionner un Jeu',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 2.h),
            ..._gameBackgrounds.map((game) => ListTile(
                  leading: Container(
                    width: 12.w,
                    height: 12.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      image: DecorationImage(
                        image: NetworkImage(game['image'] as String),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  title: Text(
                    game['name'] as String,
                    style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  subtitle: Text(
                    game['genre'] as String,
                    style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  trailing: _currentGameId == game['id']
                      ? CustomIconWidget(
                          iconName: 'check_circle',
                          color: AppTheme.successColor,
                          size: 5.w,
                        )
                      : null,
                  onTap: () {
                    setState(() {
                      _currentGameId = game['id'] as String;
                    });
                    Navigator.pop(context);
                  },
                )),
          ],
        ),
      ),
    );
  }

  void _showExitConfirmation() {
    if (!_hasUnsavedChanges) {
      Navigator.pop(context);
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        title: Text(
          'Modifications non sauvegardées',
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Vous avez des modifications non sauvegardées. Voulez-vous les sauvegarder avant de quitter ?',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text(
              'Quitter sans sauvegarder',
              style: TextStyle(color: AppTheme.errorColor),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Annuler',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _saveControls();
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.successColor,
            ),
            child: Text(
              'Sauvegarder et quitter',
              style: TextStyle(color: AppTheme.primaryDark),
            ),
          ),
        ],
      ),
    );
  }

  void _showResetConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        title: Text(
          'Réinitialiser les contrôles',
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Cette action supprimera tous les contrôles personnalisés et restaurera la configuration par défaut. Cette action est irréversible.',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Annuler',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _resetToDefault();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.warningColor,
            ),
            child: Text(
              'Réinitialiser',
              style: TextStyle(color: AppTheme.primaryDark),
            ),
          ),
        ],
      ),
    );
  }

  void _resetToDefault() {
    setState(() {
      _loadDefaultControls();
      _selectedControlId = null;
      _hasUnsavedChanges = true;
    });
    _triggerAutoSave();
  }

  void _saveControls() {
    setState(() {
      _isAutoSaving = true;
    });

    // Simulate save operation
    Future.delayed(Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _isAutoSaving = false;
          _hasUnsavedChanges = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Configuration sauvegardée avec succès',
              style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.textPrimary,
              ),
            ),
            backgroundColor: AppTheme.successColor,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    });
  }

  void _triggerAutoSave() {
    // Debounced auto-save after 3 seconds of inactivity
    Future.delayed(Duration(seconds: 3), () {
      if (_hasUnsavedChanges && mounted) {
        _saveControls();
      }
    });
  }
}
