import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class StreamingTestWidget extends StatefulWidget {
  final VoidCallback onTestComplete;
  final VoidCallback onRetry;

  const StreamingTestWidget({
    Key? key,
    required this.onTestComplete,
    required this.onRetry,
  }) : super(key: key);

  @override
  State<StreamingTestWidget> createState() => _StreamingTestWidgetState();
}

class _StreamingTestWidgetState extends State<StreamingTestWidget>
    with TickerProviderStateMixin {
  late AnimationController _testAnimationController;
  late Animation<double> _testAnimation;

  bool _isTesting = true;
  int _currentTestStep = 0;
  Map<String, dynamic> _testResults = {};

  final List<Map<String, dynamic>> _testSteps = [
    {
      'name': 'Bande Passante',
      'key': 'bandwidth',
      'icon': 'speed',
      'duration': 3,
    },
    {
      'name': 'Latence',
      'key': 'latency',
      'duration': 2,
      'icon': 'timer',
    },
    {
      'name': 'Qualité Vidéo',
      'key': 'video_quality',
      'duration': 4,
      'icon': 'high_quality',
    },
    {
      'name': 'Stabilité',
      'key': 'stability',
      'duration': 3,
      'icon': 'network_check',
    },
  ];

  @override
  void initState() {
    super.initState();
    _testAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _testAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
          parent: _testAnimationController, curve: Curves.easeInOut),
    );
    _startStreamingTest();
  }

  void _startStreamingTest() {
    _testAnimationController.repeat();
    _runTests();
  }

  void _runTests() async {
    for (int i = 0; i < _testSteps.length; i++) {
      if (!mounted) return;

      setState(() {
        _currentTestStep = i;
      });

      final step = _testSteps[i];
      final duration = step['duration'] as int;

      await Future.delayed(Duration(seconds: duration));

      if (mounted) {
        // Generate mock test results
        _testResults[step['key']] = _generateTestResult(step['key']);
      }
    }

    if (mounted) {
      setState(() {
        _isTesting = false;
        _currentTestStep = _testSteps.length;
      });
      _testAnimationController.stop();
    }
  }

  Map<String, dynamic> _generateTestResult(String testKey) {
    switch (testKey) {
      case 'bandwidth':
        return {
          'value': 85.6,
          'unit': 'Mbps',
          'status': 'excellent',
          'recommendation': '4K streaming supporté',
        };
      case 'latency':
        return {
          'value': 12,
          'unit': 'ms',
          'status': 'excellent',
          'recommendation': 'Idéal pour les jeux compétitifs',
        };
      case 'video_quality':
        return {
          'value': 92,
          'unit': '%',
          'status': 'excellent',
          'recommendation': 'Qualité maximale recommandée',
        };
      case 'stability':
        return {
          'value': 98.5,
          'unit': '%',
          'status': 'excellent',
          'recommendation': 'Connexion très stable',
        };
      default:
        return {
          'value': 0,
          'unit': '',
          'status': 'unknown',
          'recommendation': '',
        };
    }
  }

  String _getStatusColor(String status) {
    switch (status) {
      case 'excellent':
        return 'success';
      case 'good':
        return 'warning';
      case 'poor':
        return 'error';
      default:
        return 'secondary';
    }
  }

  Color _getStatusColorValue(String status) {
    switch (status) {
      case 'excellent':
        return AppTheme.successColor;
      case 'good':
        return AppTheme.warningColor;
      case 'poor':
        return AppTheme.errorColor;
      default:
        return AppTheme.textSecondary;
    }
  }

  @override
  void dispose() {
    _testAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildHeader(),
        SizedBox(height: 4.h),
        _buildTestProgress(),
        SizedBox(height: 3.h),
        _buildTestResults(),
        SizedBox(height: 3.h),
        if (!_isTesting) _buildVideoPreview(),
        SizedBox(height: 4.h),
        _buildActionButtons(),
      ],
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Test de Streaming',
          style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          _isTesting
              ? 'Évaluation de la qualité de connexion en cours...'
              : 'Tests terminés - Connexion prête pour le streaming',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildTestProgress() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Progression des Tests',
                style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${_currentTestStep}/${_testSteps.length}',
                style: AppTheme.dataTextTheme().bodyMedium?.copyWith(
                      color: AppTheme.accentColor,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          LinearProgressIndicator(
            value: _currentTestStep / _testSteps.length,
            backgroundColor: AppTheme.borderColor,
            valueColor: AlwaysStoppedAnimation<Color>(AppTheme.accentColor),
            minHeight: 1.h,
          ),
          SizedBox(height: 3.h),
          if (_isTesting && _currentTestStep < _testSteps.length)
            _buildCurrentTest(),
        ],
      ),
    );
  }

  Widget _buildCurrentTest() {
    final currentTest = _testSteps[_currentTestStep];

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.accentColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.accentColor.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _testAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: 0.8 + (_testAnimation.value * 0.4),
                child: CustomIconWidget(
                  iconName: currentTest['icon'],
                  color: AppTheme.accentColor,
                  size: 24,
                ),
              );
            },
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Test en cours: ${currentTest['name']}',
                  style: AppTheme.darkTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'Analyse de la performance...',
                  style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 6.w,
            height: 6.w,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.accentColor),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTestResults() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Résultats des Tests',
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 3.w,
            mainAxisSpacing: 2.h,
            childAspectRatio: 1.2,
          ),
          itemCount: _testSteps.length,
          itemBuilder: (context, index) {
            final step = _testSteps[index];
            final result = _testResults[step['key']];
            final isCompleted = result != null;
            final isCurrent = _isTesting && _currentTestStep == index;

            return _buildTestResultCard(step, result, isCompleted, isCurrent);
          },
        ),
      ],
    );
  }

  Widget _buildTestResultCard(Map<String, dynamic> step,
      Map<String, dynamic>? result, bool isCompleted, bool isCurrent) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isCurrent
              ? AppTheme.accentColor
              : isCompleted
                  ? _getStatusColorValue(result!['status'])
                  : AppTheme.borderColor,
          width: isCurrent ? 2 : 1,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: step['icon'],
            color: isCompleted
                ? _getStatusColorValue(result!['status'])
                : isCurrent
                    ? AppTheme.accentColor
                    : AppTheme.textSecondary,
            size: 24,
          ),
          SizedBox(height: 1.h),
          Text(
            step['name'],
            style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 1.h),
          if (isCompleted)
            Column(
              children: [
                Text(
                  '${result!['value']} ${result['unit']}',
                  style: AppTheme.dataTextTheme().headlineSmall?.copyWith(
                        color: _getStatusColorValue(result['status']),
                        fontWeight: FontWeight.w700,
                      ),
                ),
                Text(
                  result['status'].toString().toUpperCase(),
                  style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                    color: _getStatusColorValue(result['status']),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            )
          else if (isCurrent)
            SizedBox(
              width: 4.w,
              height: 4.w,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.accentColor),
              ),
            )
          else
            Text(
              'En attente',
              style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.textSecondary,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildVideoPreview() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'play_circle_filled',
                color: AppTheme.successColor,
                size: 20,
              ),
              SizedBox(width: 3.w),
              Text(
                'Aperçu Streaming',
                style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          Container(
            width: double.infinity,
            height: 25.h,
            decoration: BoxDecoration(
              color: AppTheme.primaryDark,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.borderColor),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Simulated video preview
                Container(
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        AppTheme.accentColor.withValues(alpha: 0.3),
                        AppTheme.successColor.withValues(alpha: 0.2),
                      ],
                    ),
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'videogame_asset',
                      color: AppTheme.textPrimary,
                      size: 48,
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Aperçu du Bureau PC',
                      style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'Qualité: 1080p • 60 FPS',
                      style: AppTheme.dataTextTheme().bodyMedium?.copyWith(
                            color: AppTheme.successColor,
                          ),
                    ),
                  ],
                ),
                // Quality indicators
                Positioned(
                  top: 2.w,
                  right: 2.w,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.w),
                    decoration: BoxDecoration(
                      color: AppTheme.successColor.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'signal_cellular_4_bar',
                          color: Colors.white,
                          size: 12,
                        ),
                        SizedBox(width: 1.w),
                        Text(
                          'EXCELLENT',
                          style:
                              AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    if (_isTesting) {
      return SizedBox(
        width: double.infinity,
        child: OutlinedButton(
          onPressed: () {
            setState(() {
              _isTesting = false;
              _currentTestStep = 0;
              _testResults.clear();
            });
            _testAnimationController.stop();
          },
          style: OutlinedButton.styleFrom(
            padding: EdgeInsets.symmetric(vertical: 1.5.h),
            side: BorderSide(color: AppTheme.textSecondary),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: Text(
            'Annuler les Tests',
            style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
              color: AppTheme.textSecondary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              setState(() {
                _isTesting = true;
                _currentTestStep = 0;
                _testResults.clear();
              });
              _startStreamingTest();
            },
            style: OutlinedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 1.5.h),
              side: BorderSide(color: AppTheme.accentColor),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Refaire les Tests',
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.accentColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
        SizedBox(width: 4.w),
        Expanded(
          flex: 2,
          child: ElevatedButton(
            onPressed: widget.onTestComplete,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.successColor,
              foregroundColor: AppTheme.primaryDark,
              padding: EdgeInsets.symmetric(vertical: 1.5.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Commencer le Streaming',
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.primaryDark,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ],
    );
  }
}